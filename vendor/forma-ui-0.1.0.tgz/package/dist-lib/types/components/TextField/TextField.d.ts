import type { ComponentPropsWithoutRef } from 'react';
export interface TextFieldProps extends Omit<ComponentPropsWithoutRef<'input'>, 'id'> {
    id: string;
    label: string;
    error?: string;
    hint?: string;
}
export declare function TextField({ id, label, error, hint, ...inputProps }: TextFieldProps): import("react").JSX.Element;
