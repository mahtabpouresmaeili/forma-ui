import type { AnchorHTMLAttributes, ButtonHTMLAttributes } from 'react';
export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg';
interface ButtonStyleProps {
    variant?: ButtonVariant;
    size?: ButtonSize;
    className?: string;
}
type NativeButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & ButtonStyleProps & {
    as?: 'button';
    isLoading?: boolean;
};
type AnchorButtonProps = AnchorHTMLAttributes<HTMLAnchorElement> & ButtonStyleProps & {
    as: "a";
    href: string;
    isLoading?: never;
};
type ButtonProps = NativeButtonProps | AnchorButtonProps;
export declare function Button(props: ButtonProps): import("react").JSX.Element;
export {};
