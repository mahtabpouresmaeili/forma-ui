import { Fragment as e, jsx as t, jsxs as n } from "react/jsx-runtime";
var r = {
	button: "_button_s3wn7_1",
	primary: "_primary_s3wn7_27",
	secondary: "_secondary_s3wn7_37",
	outline: "_outline_s3wn7_47",
	ghost: "_ghost_s3wn7_58",
	danger: "_danger_s3wn7_68",
	small: "_small_s3wn7_79",
	medium: "_medium_s3wn7_84",
	large: "_large_s3wn7_89",
	spinner: "_spinner_s3wn7_94",
	spin: "_spin_s3wn7_94",
	"text-field": "_text-field_s3wn7_120",
	visuallyHidden: "_visuallyHidden_s3wn7_125"
}, i = {
	primary: r.primary,
	secondary: r.secondary,
	outline: r.outline,
	ghost: r.ghost,
	danger: r.danger
}, a = {
	sm: r.small,
	md: r.medium,
	lg: r.large
};
function o(o) {
	let s = [
		r.button,
		i[o.variant ?? "primary"],
		a[o.size ?? "md"],
		o.className
	].filter(Boolean).join(" ");
	if (o.as === "a") {
		let { as: e, children: n, variant: r, size: i, className: a, ...c } = o;
		return /* @__PURE__ */ t("a", {
			...c,
			className: s,
			children: n
		});
	}
	let { as: c, variant: l, size: u, className: d, children: f, isLoading: p = !1, ...m } = o;
	return /* @__PURE__ */ t("button", {
		...m,
		className: s,
		disabled: p || m.disabled,
		"aria-busy": p || void 0,
		children: p ? /* @__PURE__ */ n(e, { children: [/* @__PURE__ */ t("span", {
			className: r.spinner,
			"aria-hidden": "true"
		}), /* @__PURE__ */ t("span", {
			className: r.visuallyHidden,
			children: f
		})] }) : f
	});
}
var s = {
	field: "_field_ez6ho_1",
	label: "_label_ez6ho_7",
	input: "_input_ez6ho_13",
	hint: "_hint_ez6ho_33",
	error: "_error_ez6ho_34"
};
// src/components/TextField/TextField.tsx
function c({ id: e, label: r, error: i, hint: a, ...o }) {
	let c = [a ? `${e}-hint` : void 0, i ? `${e}-error` : void 0].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ n("div", {
		className: s.field,
		children: [
			/* @__PURE__ */ t("label", {
				className: s.label,
				htmlFor: e,
				children: r
			}),
			/* @__PURE__ */ t("input", {
				...o,
				className: [s.input, o.className].filter(Boolean).join(" "),
				id: e,
				"aria-invalid": i ? !0 : o["aria-invalid"],
				"aria-describedby": [o["aria-describedby"], c].filter(Boolean).join(" ") || void 0
			}),
			a && /* @__PURE__ */ t("p", {
				className: s.hint,
				id: `${e}-hint`,
				children: a
			}),
			i && /* @__PURE__ */ t("p", {
				className: s.error,
				id: `${e}-error`,
				children: i
			})
		]
	});
}
export { o as Button, c as TextField };
