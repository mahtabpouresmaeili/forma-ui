# Forma UI

Accessible, themeable React components built with TypeScript and CSS custom properties.

## Install

```sh
npm install @mahtab7/forma-ui
```

Import the stylesheet once in your application entry point:

```tsx
import '@mahtab7/forma-ui/style.css';
```

```tsx
import { Button, TextField } from '@mahtab7/forma-ui';

export function Example() {
  return <><Button variant="primary">Save</Button><TextField id="email" label="Email" type="email" /></>;
}
```

React 18 or 19 is a peer dependency. The package ships ES modules, TypeScript declarations, and the component stylesheet. The `prepublishOnly` script builds the distributable before publishing.

## Components

- [Button API and examples](docs/components/Button.md)
- [TextField API and examples](docs/components/TextField.md)

## Customize design tokens

Components use CSS custom properties. Override tokens on `:root` for a global theme, or on a container to scope a theme. Place overrides after the package stylesheet.

```css
:root {
  --color-primary: #176b5b;
  --color-primary-hover: #105044;
  --color-focus-ring: #0b8068;
  --radius-md: 12px;
  --font-sans: Inter, system-ui, sans-serif;
}

.customer-theme {
  --color-primary: #7c3aed;
  --color-primary-hover: #6d28d9;
  --color-focus-ring: #a78bfa;
  --radius-md: 4px;
}
```

See [the token reference](docs/design-tokens.md) for the full set, fallback values, and semantic guidance. CSS Modules scope component selectors, while the custom properties remain inheritable and themeable.

## Accessibility

Forma UI uses native buttons, anchors and inputs; visible keyboard focus; associated labels and descriptions; and reduced-motion styles. Supply meaningful button text and a unique `id` and label for each `TextField`. For validation, pass an error message and set `aria-invalid` if you need to communicate an invalid state before displaying that message. Review [the component accessibility guidance](docs/accessibility.md) and validate the consuming application with keyboard and assistive technology.

## Development

```sh
npm install
npm run dev
npm run build
npm run build:lib
npm test -- --run
```

## Release checklist

1. Update the package version using SemVer and commit the matching lockfile change (`npm version patch|minor|major`).
2. Confirm the chosen license and repository metadata are correct. This project currently declares MIT; include a `LICENSE` file before publishing.
3. Run `npm run build:lib` and `npm run pack:check`; inspect the package file list and test installation in a clean consumer project.
4. Authenticate with npm, then publish the scoped package: `npm publish --access public` (first public publish for a scope may need this flag).
5. Create a Git tag/release matching the package version and verify the published tarball and README.

Publishing to npm and creating a GitHub release require maintainer credentials and are release actions; this repository is prepared for that workflow but has not been published by these instructions.
